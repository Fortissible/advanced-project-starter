import 'package:flutter/material.dart';

class GithubSearchPage extends StatelessWidget {
  const GithubSearchPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(child: Text("Github Search Page"));
  }
}