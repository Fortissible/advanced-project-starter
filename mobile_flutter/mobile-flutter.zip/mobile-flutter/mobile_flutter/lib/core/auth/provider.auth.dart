abstract class TokenProvider {
  Future<String?> getAccessToken();
}