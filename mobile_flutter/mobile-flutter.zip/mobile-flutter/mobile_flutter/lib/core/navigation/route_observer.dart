import 'package:flutter/cupertino.dart';

final RouteObserver<ModalRoute> routeObserver = RouteObserver<ModalRoute>();