import 'package:mobile_flutter/data/remote_data_source/posts/posts.remote_data_source.dart';

class DummyJsonApiService {
  final PostsRemoteDataSource posts;

  DummyJsonApiService({
    required this.posts,
  });
}